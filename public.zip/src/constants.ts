export const ASSET_URL =
  "https://app.nftrade.com/users/bsc/0x83a0277d29092219188d7bc596418f11c6b62c9c";

export enum EmbedTheme {
  Default = "true",
  Simple = "simple",
}

export const CHOSEN_THEME = EmbedTheme.Default;
